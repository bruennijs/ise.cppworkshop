
#include "f.hpp"
#include <iostream>

void f2()
{}

X obj;

