
#include "f.hpp"

int main()
{
	f1();
	f2();
}